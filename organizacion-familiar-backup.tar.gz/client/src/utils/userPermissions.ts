// Sistema de permisos de usuarios
export type UserRole = 'javi_administrador' | 'javier' | 'raquel' | 'mario' | 'alba';

export interface UserPermissions {
  canEdit: boolean;
  canAddItems: boolean;
  canMarkCompleted: boolean;
  canViewSection: boolean;
  canAddToShoppingList: boolean;
  canSendMessages: boolean;
}

export interface SectionAccess {
  inicio: boolean;
  actividades: boolean;
  calendario_comidas: boolean;
  recetas: boolean;
  inventario: boolean;
  lista_compra: boolean;
  mensajes: boolean;
}

// Configuración de permisos por usuario y sección
export const USER_PERMISSIONS: Record<UserRole, Record<string, UserPermissions>> = {
  javi_administrador: {
    inicio: { canEdit: true, canAddItems: true, canMarkCompleted: true, canViewSection: true, canAddToShoppingList: true, canSendMessages: true },
    actividades: { canEdit: true, canAddItems: true, canMarkCompleted: true, canViewSection: true, canAddToShoppingList: true, canSendMessages: true },
    calendario_comidas: { canEdit: true, canAddItems: true, canMarkCompleted: true, canViewSection: true, canAddToShoppingList: true, canSendMessages: true },
    recetas: { canEdit: true, canAddItems: true, canMarkCompleted: true, canViewSection: true, canAddToShoppingList: true, canSendMessages: true },
    inventario: { canEdit: true, canAddItems: true, canMarkCompleted: true, canViewSection: true, canAddToShoppingList: true, canSendMessages: true },
    lista_compra: { canEdit: true, canAddItems: true, canMarkCompleted: true, canViewSection: true, canAddToShoppingList: true, canSendMessages: true },
    mensajes: { canEdit: true, canAddItems: true, canMarkCompleted: true, canViewSection: true, canAddToShoppingList: true, canSendMessages: true }
  },
  javier: {
    inicio: { canEdit: false, canAddItems: false, canMarkCompleted: false, canViewSection: true, canAddToShoppingList: false, canSendMessages: false },
    actividades: { canEdit: false, canAddItems: false, canMarkCompleted: true, canViewSection: true, canAddToShoppingList: false, canSendMessages: false },
    calendario_comidas: { canEdit: false, canAddItems: false, canMarkCompleted: true, canViewSection: true, canAddToShoppingList: false, canSendMessages: false },
    recetas: { canEdit: false, canAddItems: false, canMarkCompleted: false, canViewSection: true, canAddToShoppingList: false, canSendMessages: false },
    inventario: { canEdit: false, canAddItems: false, canMarkCompleted: false, canViewSection: true, canAddToShoppingList: false, canSendMessages: false },
    lista_compra: { canEdit: false, canAddItems: false, canMarkCompleted: false, canViewSection: true, canAddToShoppingList: true, canSendMessages: false },
    mensajes: { canEdit: false, canAddItems: false, canMarkCompleted: false, canViewSection: true, canAddToShoppingList: false, canSendMessages: true }
  },
  raquel: {
    inicio: { canEdit: false, canAddItems: false, canMarkCompleted: false, canViewSection: true, canAddToShoppingList: false, canSendMessages: false },
    actividades: { canEdit: false, canAddItems: false, canMarkCompleted: true, canViewSection: true, canAddToShoppingList: false, canSendMessages: false },
    calendario_comidas: { canEdit: false, canAddItems: false, canMarkCompleted: true, canViewSection: true, canAddToShoppingList: false, canSendMessages: false },
    recetas: { canEdit: false, canAddItems: false, canMarkCompleted: false, canViewSection: true, canAddToShoppingList: false, canSendMessages: false },
    inventario: { canEdit: false, canAddItems: false, canMarkCompleted: false, canViewSection: true, canAddToShoppingList: false, canSendMessages: false },
    lista_compra: { canEdit: false, canAddItems: false, canMarkCompleted: false, canViewSection: true, canAddToShoppingList: true, canSendMessages: false },
    mensajes: { canEdit: false, canAddItems: false, canMarkCompleted: false, canViewSection: true, canAddToShoppingList: false, canSendMessages: true }
  },
  mario: {
    inicio: { canEdit: false, canAddItems: false, canMarkCompleted: false, canViewSection: true, canAddToShoppingList: false, canSendMessages: false },
    actividades: { canEdit: false, canAddItems: false, canMarkCompleted: true, canViewSection: true, canAddToShoppingList: false, canSendMessages: false },
    calendario_comidas: { canEdit: false, canAddItems: false, canMarkCompleted: true, canViewSection: true, canAddToShoppingList: false, canSendMessages: false },
    recetas: { canEdit: false, canAddItems: false, canMarkCompleted: false, canViewSection: false, canAddToShoppingList: false, canSendMessages: false }, // Mario no tiene acceso a recetas
    inventario: { canEdit: false, canAddItems: false, canMarkCompleted: false, canViewSection: true, canAddToShoppingList: false, canSendMessages: false },
    lista_compra: { canEdit: false, canAddItems: false, canMarkCompleted: false, canViewSection: true, canAddToShoppingList: true, canSendMessages: false },
    mensajes: { canEdit: false, canAddItems: false, canMarkCompleted: false, canViewSection: true, canAddToShoppingList: false, canSendMessages: true }
  },
  alba: {
    inicio: { canEdit: false, canAddItems: false, canMarkCompleted: false, canViewSection: true, canAddToShoppingList: false, canSendMessages: false },
    actividades: { canEdit: false, canAddItems: false, canMarkCompleted: true, canViewSection: true, canAddToShoppingList: false, canSendMessages: false },
    calendario_comidas: { canEdit: false, canAddItems: false, canMarkCompleted: true, canViewSection: true, canAddToShoppingList: false, canSendMessages: false },
    recetas: { canEdit: false, canAddItems: false, canMarkCompleted: false, canViewSection: false, canAddToShoppingList: false, canSendMessages: false }, // Alba no tiene acceso a recetas
    inventario: { canEdit: false, canAddItems: false, canMarkCompleted: false, canViewSection: true, canAddToShoppingList: false, canSendMessages: false },
    lista_compra: { canEdit: false, canAddItems: false, canMarkCompleted: false, canViewSection: true, canAddToShoppingList: true, canSendMessages: false },
    mensajes: { canEdit: false, canAddItems: false, canMarkCompleted: false, canViewSection: true, canAddToShoppingList: false, canSendMessages: true }
  }
};

// Configuración de acceso a secciones por usuario
export const SECTION_ACCESS: Record<UserRole, SectionAccess> = {
  javi_administrador: {
    inicio: true,
    actividades: true,
    calendario_comidas: true,
    recetas: true,
    inventario: true,
    lista_compra: true,
    mensajes: true
  },
  javier: {
    inicio: true,
    actividades: true,
    calendario_comidas: true,
    recetas: true,
    inventario: true,
    lista_compra: true,
    mensajes: true
  },
  raquel: {
    inicio: true,
    actividades: true,
    calendario_comidas: true,
    recetas: true,
    inventario: true,
    lista_compra: true,
    mensajes: true
  },
  mario: {
    inicio: true,
    actividades: true,
    calendario_comidas: true,
    recetas: false, // Mario no tiene acceso a recetas
    inventario: true,
    lista_compra: true,
    mensajes: true
  },
  alba: {
    inicio: true,
    actividades: true,
    calendario_comidas: true,
    recetas: false, // Alba no tiene acceso a recetas
    inventario: true,
    lista_compra: true,
    mensajes: true
  }
};

// Categorías de compra actualizadas
export const PURCHASE_CATEGORIES = [
  { value: 'carniceria_online', label: 'Carnicería online' },
  { value: 'pescaderia', label: 'Pescadería' },
  { value: 'del_bancal_a_casa', label: 'Del bancal a casa' },
  { value: 'alcampo', label: 'Alcampo' },
  { value: 'lidl', label: 'Lidl' },
  { value: 'internet', label: 'Internet' },
  { value: 'otros', label: 'Otros' }
];

// Función para obtener rol de usuario basado en email
export function getUserRole(email: string): UserRole {
  if (email === 'jamusanchez+admin@gmail.com') return 'javi_administrador';
  if (email === 'jamusanchez@gmail.com') return 'javier';
  if (email.includes('raquel')) return 'raquel';
  if (email.includes('mario')) return 'mario';
  if (email.includes('alba')) return 'alba';
  return 'javier'; // default
}

// Función para obtener permisos de usuario
export function getUserPermissions(userRole: UserRole, section: string): UserPermissions {
  return USER_PERMISSIONS[userRole]?.[section] || {
    canEdit: false,
    canAddItems: false,
    canMarkCompleted: false,
    canViewSection: false,
    canAddToShoppingList: false,
    canSendMessages: false
  };
}

// Función para verificar acceso a sección
export function canAccessSection(userRole: UserRole, section: keyof SectionAccess): boolean {
  return SECTION_ACCESS[userRole]?.[section] || false;
}