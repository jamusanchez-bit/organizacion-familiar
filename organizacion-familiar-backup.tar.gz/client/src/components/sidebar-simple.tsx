import { Button } from "@/components/ui/button";
import { Calendar, Home, Utensils, Package, LogOut, ChefHat, X, ShoppingCart, MessageSquare } from "lucide-react";
import { getUserRole, canAccessSection, type UserRole } from "@/utils/userPermissions";
import { useAuth } from "@/hooks/useAuth";

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  lowStockCount: number;
  userName: string;
}

export default function SimpleSidebar({ activeTab, setActiveTab, lowStockCount, userName }: SidebarProps) {
  const { user } = useAuth();
  const selectedFamilyUser = localStorage.getItem('selectedFamilyUser') || 'javier';
  const userRole = (selectedFamilyUser === 'javi_administrador' ? 'javi_administrador' : selectedFamilyUser) as UserRole;
  
  const handleLogout = () => {
    // Limpiar el usuario seleccionado al cerrar sesión
    localStorage.removeItem('selectedFamilyUser');
    window.location.href = "/api/auth/logout";
  };

  const handleTabChange = (tab: string) => {
    setActiveTab(tab); // Esta función ya maneja el cierre del sidebar móvil en el componente padre
  };

  const navItems = [
    { id: 'dashboard', label: 'Inicio', icon: Home, section: 'inicio' },
    { id: 'activities', label: 'Actividades', icon: Calendar, section: 'actividades' },
    { id: 'meal-calendar', label: 'Calendario de comidas', icon: Utensils, section: 'calendario_comidas' },
    { id: 'recipes', label: 'Recetas', icon: ChefHat, section: 'recetas' },
    { 
      id: 'inventory', 
      label: 'Inventario', 
      icon: Package,
      section: 'inventario',
      badge: lowStockCount > 0 ? lowStockCount : undefined
    },
    { id: 'shopping-list', label: 'Lista de la compra', icon: ShoppingCart, section: 'lista_compra' },
    { id: 'messages', label: 'Mensajes', icon: MessageSquare, section: 'mensajes' }
  ].filter(item => canAccessSection(userRole, item.section as any));

  return (
    <div className="w-64 bg-white shadow-lg border-r border-neutral-200 h-full flex flex-col relative">
      {/* Header */}
      <div className="p-6 border-b border-neutral-200 lg:flex lg:items-center lg:justify-between">
        <div>
          <h1 className="text-xl font-bold text-neutral-800 flex items-center">
            <Calendar className="text-primary mr-2 h-6 w-6" />
            Organización Familiar
          </h1>
          <p className="text-sm text-neutral-500 mt-1">Bienvenido, {userName}</p>
        </div>
        {/* Botón cerrar para móvil */}
        <Button
          variant="ghost"
          size="sm"
          onClick={() => {
            // Emitir evento personalizado para cerrar sidebar desde el componente padre
            const closeEvent = new CustomEvent('closeMobileSidebar');
            window.dispatchEvent(closeEvent);
          }}
          className="lg:hidden absolute top-4 right-4 p-1"
          data-testid="button-close-sidebar"
        >
          <X className="h-5 w-5" />
        </Button>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-4">
        <ul className="space-y-2">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            
            return (
              <li key={item.id}>
                <Button
                  variant="ghost"
                  className={`w-full justify-start px-4 py-3 h-auto ${
                    isActive 
                      ? 'bg-primary/10 border-r-2 border-primary text-neutral-700 font-medium' 
                      : 'text-neutral-600 hover:bg-neutral-100'
                  }`}
                  onClick={() => handleTabChange(item.id)}
                  data-testid={`nav-${item.id}`}
                >
                  <Icon className={`mr-3 h-5 w-5 ${isActive ? 'text-primary' : ''}`} />
                  {item.label}
                  {item.badge && (
                    <span className="ml-auto bg-accent text-white text-xs px-2 py-1 rounded-full" data-testid="badge-low-stock">
                      {item.badge}
                    </span>
                  )}
                </Button>
              </li>
            );
          })}
        </ul>
      </nav>

      {/* Logout */}
      <div className="p-4 border-t border-neutral-200">
        <Button
          variant="ghost"
          className="w-full justify-start px-4 py-3 text-neutral-600 hover:bg-neutral-100"
          onClick={handleLogout}
          data-testid="button-logout"
        >
          <LogOut className="mr-3 h-5 w-5" />
          Cerrar Sesión
        </Button>
      </div>
    </div>
  );
}