import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { useAuth } from "@/hooks/useAuth";
import { getDailyQuote, getFormattedDate } from "@/utils/dailyQuotes";
import { getUserRole, getUserPermissions, canAccessSection, PURCHASE_CATEGORIES, type UserRole } from "@/utils/userPermissions";
import SimpleSidebar from "@/components/sidebar-simple";
import ActivityModal from "@/components/activity-modal";
import MealModal from "@/components/meal-modal";
import MealCalendar from "@/components/meal-calendar";
import ActivitiesCalendar from "@/components/activities-calendar";
import InventoryModal from "@/components/inventory-modal";
import InventoryEditModal from "@/components/inventory-edit-modal";
import InventoryQuantityModal from "@/components/inventory-quantity-modal";
import QuickStockUpdate from "@/components/quick-stock-update";
import RecipeModal from "@/components/recipe-modal";
import RecipeEditModal from "@/components/recipe-edit-modal";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Calendar, Utensils, Package, AlertTriangle, Plus, Menu, Edit2, ChefHat, Clock, Users, Zap, Send, ShoppingCart, MessageSquare } from "lucide-react";
import { useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { format } from "date-fns";
import type { Activity, Meal, InventoryItem, Recipe, RecipeIngredient, ShoppingListItem, Message } from "@shared/schema";

export default function Home() {
  // State management
  const [activeTab, setActiveTab] = useState('dashboard');
  const [showActivityModal, setShowActivityModal] = useState(false);
  const [showMealModal, setShowMealModal] = useState(false);
  const [showInventoryModal, setShowInventoryModal] = useState(false);
  const [showRecipeModal, setShowRecipeModal] = useState(false);
  const [editingActivity, setEditingActivity] = useState<Activity | null>(null);
  const [editingMeal, setEditingMeal] = useState<Meal | null>(null);
  const [editingInventoryItem, setEditingInventoryItem] = useState<InventoryItem | null>(null);
  const [editingRecipe, setEditingRecipe] = useState<Recipe | null>(null);
  const [sidebarOpen, setSidebarOpen] = useState(false);

  // Función para manejar cambio de tab y cerrar sidebar móvil
  const handleTabChange = (tab: string) => {
    setActiveTab(tab);
    setSidebarOpen(false); // Cerrar sidebar móvil siempre que se cambie tab
  };

  // Listener para cerrar sidebar móvil con evento personalizado
  useEffect(() => {
    const handleCloseSidebar = () => {
      setSidebarOpen(false);
    };

    window.addEventListener('closeMobileSidebar', handleCloseSidebar);
    return () => {
      window.removeEventListener('closeMobileSidebar', handleCloseSidebar);
    };
  }, []);

  const { toast } = useToast();
  const { user, isLoading: authLoading } = useAuth();
  const isAuthenticated = !!user;

  const userNames = ['javier', 'raquel', 'mario', 'alba'];
  const selectedFamilyUser = localStorage.getItem('selectedFamilyUser') || 'javier';
  const currentUser = selectedFamilyUser === 'javi_administrador' ? 'javier' : selectedFamilyUser;
  // Determinar el rol basado en el usuario seleccionado
  const userRole = (selectedFamilyUser === 'javi_administrador' ? 'javi_administrador' : selectedFamilyUser) as UserRole;
  const dailyQuote = getDailyQuote();
  const formattedDate = getFormattedDate();

  // Dashboard/Home Section
  const renderDashboard = () => {
    const todayActivities = activities?.filter(activity => 
      activity.date === format(new Date(), 'yyyy-MM-dd') && 
      activity.assignedTo === currentUser
    ) || [];
    
    return (
    <div className="p-6">
      <div className="mb-6">
        <h2 className="text-3xl font-bold text-neutral-800 mb-2">Inicio</h2>
        <p className="text-lg text-neutral-700 mb-2">{formattedDate}</p>
        <blockquote className="text-neutral-600 italic border-l-4 border-blue-500 pl-4 mb-4">
          "{dailyQuote}"
        </blockquote>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <Card className="border-neutral-200" data-testid="card-stats-activities">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-neutral-600">Actividades Hoy</p>
                <p className="text-2xl font-bold text-neutral-800">{todayActivities.length}</p>
              </div>
              <div className="p-3 bg-primary/10 rounded-lg">
                <Calendar className="text-primary h-6 w-6" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-neutral-200" data-testid="card-stats-meals">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-neutral-600">Comidas Hoy</p>
                <p className="text-2xl font-bold text-neutral-800">{todayMeals.length}</p>
              </div>
              <div className="p-3 bg-secondary/10 rounded-lg">
                <Utensils className="text-secondary h-6 w-6" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-neutral-200" data-testid="card-stats-inventory">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-neutral-600">Items en Stock</p>
                <p className="text-2xl font-bold text-neutral-800">{inventory.length}</p>
              </div>
              <div className="p-3 bg-accent/10 rounded-lg">
                <Package className="text-accent h-6 w-6" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-neutral-200" data-testid="card-stats-low-stock">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-neutral-600">Stock Bajo</p>
                <p className="text-2xl font-bold text-red-600">{lowStockItems.length}</p>
              </div>
              <div className="p-3 bg-red-50 rounded-lg">
                <AlertTriangle className="text-red-500 h-6 w-6" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
    );
  };

  const renderActivitiesCalendar = () => {
    const permissions = getUserPermissions(userRole, 'actividades');
    
    return (
      <div className="p-6">
        <ActivitiesCalendar 
          userRole={userRole}
          currentUser={currentUser}
          canAddActivities={permissions.canAddItems}
          canMarkCompleted={permissions.canMarkCompleted}
        />
      </div>
    );
  };

  const renderMealCalendar = () => {
    const permissions = getUserPermissions(userRole, 'calendario_comidas');
    
    return (
      <div className="p-6">
        <MealCalendar 
          userRole={userRole}
          canAddMeals={permissions.canAddItems}
        />
      </div>
    );
  };

  const renderInventory = () => {
    const permissions = getUserPermissions(userRole, 'inventario');
    
    return (
      <div className="p-6">
        <div className="max-w-7xl mx-auto">
          <div className="mb-6 flex justify-between items-center">
            <div>
              <h1 className="text-2xl font-bold text-neutral-800 mb-2">Inventario</h1>
              <p className="text-neutral-600">
                {permissions.canAddItems ? 'Gestiona tu stock de alimentos' : 'Consulta el stock disponible'}
              </p>
            </div>
            {permissions.canAddItems && (
              <div className="space-x-2">
                <Button 
                  onClick={() => setShowInventoryModal(true)}
                  data-testid="button-add-inventory-item"
                >
                  <Plus className="h-4 w-4 mr-2" />
                  Añadir Item
                </Button>
              </div>
            )}
          </div>

          {/* Agrupar productos por subcategoría */}
          {(() => {
            // Agrupar por subcategoría
            const groupedItems = inventory.reduce((groups, item) => {
              const subcategory = item.category || 'Sin categoría';
              if (!groups[subcategory]) {
                groups[subcategory] = [];
              }
              groups[subcategory].push(item);
              return groups;
            }, {} as Record<string, typeof inventory>);

            // Ordenar categorías alfabéticamente
            const sortedCategories = Object.keys(groupedItems).sort();

            return (
              <div className="space-y-6">
                {sortedCategories.map((subcategory) => (
                  <Card key={subcategory} className="border-neutral-200">
                    <CardContent className="p-6">
                      <h3 className="text-lg font-semibold text-neutral-800 mb-4 capitalize flex items-center">
                        <Package className="h-5 w-5 mr-2 text-neutral-600" />
                        {subcategory.replace(/_/g, ' ')} ({groupedItems[subcategory].length} productos)
                      </h3>
                      <div className="space-y-2">
                        {groupedItems[subcategory].map((item) => (
                          <div
                            key={item.id}
                            className="flex items-center justify-between p-3 bg-neutral-50 hover:bg-neutral-100 rounded-lg cursor-pointer transition-colors"
                            onClick={() => setEditingInventoryItem(item)}
                            data-testid={`item-inventory-${item.id}`}
                            title="Click para ajustar cantidad"
                          >
                            <span className="font-medium text-neutral-800">{item.name}</span>
                            <span className="text-neutral-600 font-semibold">
                              {parseFloat(item.currentQuantity)} {item.unit}
                            </span>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            );
          })()}
          
          {!permissions.canAddItems && (
            <div className="mt-6">
              <Card className="border-blue-200 bg-blue-50">
                <CardContent className="p-4">
                  <p className="text-blue-800 text-sm">
                    💡 Solo puedes modificar las cantidades de los items existentes. Para añadir nuevos items, contacta al administrador.
                  </p>
                </CardContent>
              </Card>
            </div>
          )}
        </div>
      </div>
    );
  };

  const renderRecipes = () => (
    <div className="p-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-6 flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-bold text-neutral-800 mb-2">Recetas</h1>
            <p className="text-neutral-600">Administra tus recetas favoritas</p>
          </div>
          <Button 
            onClick={() => setShowRecipeModal(true)}
            data-testid="button-add-recipe"
          >
            <Plus className="h-4 w-4 mr-2" />
            Nueva Receta
          </Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {recipes.map((recipe) => (
            <Card key={recipe.id} className="border-neutral-200" data-testid={`card-recipe-${recipe.id}`}>
              <CardContent className="p-4">
                <div className="flex items-start justify-between mb-2">
                  <div>
                    <h3 className="font-medium text-neutral-800 mb-1">{recipe.name}</h3>
                    <p className="text-sm text-neutral-600 capitalize">{recipe.category}</p>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setEditingRecipe(recipe)}
                    data-testid={`button-edit-recipe-${recipe.id}`}
                  >
                    <Edit2 className="h-3 w-3" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );

  const renderShoppingList = () => {
    const { data: shoppingList = [] } = useQuery<ShoppingListItem[]>({
      queryKey: ['/api/shopping-list'],
      enabled: isAuthenticated,
    });

    // Hook para añadir productos sin stock automáticamente
    const addLowStockMutation = useMutation({
      mutationFn: async () => {
        if (lowStockItems.length > 0) {
          for (const item of lowStockItems) {
            const exists = shoppingList.find(si => si.name === item.name);
            if (!exists) {
              await apiRequest("POST", "/api/shopping-list", {
                name: item.name,
                category: item.purchaseLocation || "otros",
                quantity: "0",
                unit: item.unit,
                isCompleted: false
              });
            }
          }
        }
      },
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: ['/api/shopping-list'] });
      }
    });

    // Ejecutar la adición automática si hay items sin stock
    if (lowStockItems.length > 0 && shoppingList.length === 0) {
      addLowStockMutation.mutate();
    }

    // Agrupar items por categoría
    const groupedItems = PURCHASE_CATEGORIES.reduce((groups, category) => {
      groups[category.value] = shoppingList.filter(item => item.category === category.value);
      return groups;
    }, {} as Record<string, ShoppingListItem[]>);

    // Lista de sugerencias por categoría
    const suggestions = {
      'carne_internet': ['Pechuga de pollo', 'Carne picada', 'Jamón serrano'],
      'pescaderia': ['Salmón', 'Merluza', 'Gambas'],
      'del_bancal_a_casa': ['Tomates', 'Lechugas', 'Zanahorias', 'Patatas'],
      'alcampo': ['Leche', 'Pan', 'Huevos', 'Yogur'],
      'internet': ['Aceite de oliva', 'Arroz', 'Pasta'],
      'otros': ['Papel higiénico', 'Detergente', 'Jabón']
    };

    return (
      <div className="p-6">
        <div className="max-w-7xl mx-auto">
          <div className="mb-6">
            <h1 className="text-2xl font-bold text-neutral-800 mb-2">Lista de la compra</h1>
            <p className="text-neutral-600">Organiza tus compras por categorías</p>
          </div>

          <div className="space-y-6">
            {PURCHASE_CATEGORIES.map((category) => {
              const items = groupedItems[category.value] || [];
              const categorySuggestions = suggestions[category.value as keyof typeof suggestions] || [];

              return (
                <Card key={category.value} className="border-neutral-200">
                  <CardContent className="p-6">
                    <h3 className="text-lg font-semibold text-neutral-800 mb-4 flex items-center">
                      <ShoppingCart className="h-5 w-5 mr-2 text-primary" />
                      {category.label} ({items.length} items)
                    </h3>
                    
                    {/* Items existentes */}
                    {items.length > 0 && (
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 mb-4">
                        {items.map((item) => (
                          <div key={item.id} className="flex items-center justify-between p-3 bg-neutral-50 rounded-lg">
                            <div>
                              <p className="font-medium text-neutral-800">{item.name}</p>
                              <p className="text-sm text-neutral-600">
                                {parseFloat(item.quantity)} {item.unit}
                              </p>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                    
                    {/* Sugerencias */}
                    {items.length === 0 && categorySuggestions.length > 0 && (
                      <div>
                        <p className="text-sm text-neutral-500 mb-3">💡 Sugerencias para esta categoría:</p>
                        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-2">
                          {categorySuggestions.map((suggestion, index) => (
                            <div key={index} className="p-2 bg-blue-50 text-blue-700 text-sm rounded border border-blue-200">
                              {suggestion}
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                    
                    {/* Mensaje si no hay items ni sugerencias */}
                    {items.length === 0 && categorySuggestions.length === 0 && (
                      <p className="text-neutral-400 text-sm">No hay productos en esta categoría</p>
                    )}
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </div>
    );
  };

  const renderMessages = () => {
    const permissions = getUserPermissions(userRole, 'mensajes');
    
    return (
      <div className="p-6">
        <div className="max-w-7xl mx-auto">
          <div className="mb-6">
            <h1 className="text-2xl font-bold text-neutral-800 mb-2">Mensajes</h1>
            <p className="text-neutral-600">Comunícate con la familia</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {/* Foro Público */}
            <Card className="border-neutral-200">
              <CardContent className="p-6">
                <div className="flex items-center mb-4">
                  <MessageSquare className="h-6 w-6 text-blue-600 mr-3" />
                  <h3 className="text-lg font-semibold text-neutral-800">Foro Público</h3>
                </div>
                <p className="text-neutral-600 mb-4">
                  Conversaciones generales entre todos los miembros de la familia
                </p>
                <Button 
                  variant="outline" 
                  className="w-full"
                  disabled={!permissions.canSendMessages}
                  data-testid="button-public-forum"
                >
                  {permissions.canSendMessages ? 'Acceder al Foro' : 'Solo Lectura'}
                </Button>
              </CardContent>
            </Card>

            {/* Sugerencias al Administrador */}
            <Card className="border-neutral-200">
              <CardContent className="p-6">
                <div className="flex items-center mb-4">
                  <MessageSquare className="h-6 w-6 text-green-600 mr-3" />
                  <h3 className="text-lg font-semibold text-neutral-800">Sugerencias</h3>
                </div>
                <p className="text-neutral-600 mb-4">
                  Envía sugerencias privadas al administrador para mejorar la organización
                </p>
                <Button 
                  variant="outline" 
                  className="w-full"
                  disabled={!permissions.canSendMessages}
                  data-testid="button-suggestions"
                >
                  {permissions.canSendMessages ? 'Enviar Sugerencia' : 'No Disponible'}
                </Button>
              </CardContent>
            </Card>

            {/* Mensajes Privados */}
            <Card className="border-neutral-200">
              <CardContent className="p-6">
                <div className="flex items-center mb-4">
                  <MessageSquare className="h-6 w-6 text-purple-600 mr-3" />
                  <h3 className="text-lg font-semibold text-neutral-800">Mensajes Privados</h3>
                </div>
                <p className="text-neutral-600 mb-4">
                  Conversaciones privadas entre miembros específicos de la familia
                </p>
                <Button 
                  variant="outline" 
                  className="w-full"
                  disabled={!permissions.canSendMessages}
                  data-testid="button-private-messages"
                >
                  {permissions.canSendMessages ? 'Ver Mensajes' : 'No Disponible'}
                </Button>
              </CardContent>
            </Card>
          </div>
          
          {userRole === 'javi_administrador' && (
            <div className="mt-8">
              <Card className="border-yellow-200 bg-yellow-50">
                <CardContent className="p-6">
                  <div className="flex items-center mb-4">
                    <MessageSquare className="h-6 w-6 text-yellow-600 mr-3" />
                    <h3 className="text-lg font-semibold text-neutral-800">Panel de Administrador</h3>
                  </div>
                  <p className="text-neutral-600 mb-4">
                    Gestiona todas las conversaciones y configuraciones de mensajería
                  </p>
                  <div className="flex space-x-2">
                    <Button variant="outline" data-testid="button-admin-messages">
                      Gestionar Mensajes
                    </Button>
                    <Button variant="outline" data-testid="button-message-settings">
                      Configuración
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}
        </div>
      </div>
    );
  };

  // Fetch data
  const { data: activities = [], isLoading: activitiesLoading } = useQuery<Activity[]>({
    queryKey: ['/api/activities'],
    enabled: isAuthenticated,
  });

  const { data: todayActivities = [] } = useQuery<Activity[]>({
    queryKey: ['/api/activities', format(new Date(), 'yyyy-MM-dd')],
    enabled: isAuthenticated,
  });

  const { data: meals = [], isLoading: mealsLoading } = useQuery<Meal[]>({
    queryKey: ['/api/meals'],
    enabled: isAuthenticated,
  });

  const { data: todayMeals = [] } = useQuery<Meal[]>({
    queryKey: ['/api/meals', format(new Date(), 'yyyy-MM-dd')],
    enabled: isAuthenticated,
  });

  const { data: inventory = [], isLoading: inventoryLoading } = useQuery<InventoryItem[]>({
    queryKey: ['/api/inventory'],
    enabled: isAuthenticated,
  });

  const { data: lowStockItems = [] } = useQuery<InventoryItem[]>({
    queryKey: ['/api/inventory/low-stock'],
    enabled: isAuthenticated,
  });

  const { data: recipes = [], isLoading: recipesLoading } = useQuery<Recipe[]>({
    queryKey: ['/api/recipes'],
    enabled: isAuthenticated,
  });

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, authLoading, toast]);

  // Loading states
  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-neutral-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-neutral-600">Cargando...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return null; // Will redirect in useEffect
  }

  return (
    <div className="min-h-screen bg-neutral-50 flex">
      {/* Desktop Sidebar */}
      <div className="hidden lg:flex lg:flex-shrink-0">
        <SimpleSidebar 
          activeTab={activeTab} 
          setActiveTab={handleTabChange}
          lowStockCount={lowStockItems.length}
          userName={(user as any)?.firstName || (user as any)?.email || 'Usuario'}
        />
      </div>

      {/* Mobile Sidebar */}
      {sidebarOpen && (
        <>
          <div 
            className="fixed inset-0 bg-black bg-opacity-50 z-40 lg:hidden"
            onClick={() => setSidebarOpen(false)}
          />
          <div className="fixed left-0 top-0 h-full z-50 lg:hidden">
            <SimpleSidebar 
              activeTab={activeTab} 
              setActiveTab={handleTabChange}
              lowStockCount={lowStockItems.length}
              userName={(user as any)?.firstName || (user as any)?.email || 'Usuario'}
            />
          </div>
        </>
      )}

      <main className="flex-1 lg:ml-0">
        {/* Mobile Header */}
        <div className="lg:hidden bg-white border-b border-neutral-200 p-4 flex items-center justify-between">
          <div className="flex items-center">
            <Calendar className="h-5 w-5 mr-2 text-primary" />
            <span className="font-bold text-neutral-800">Organización Familiar</span>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setSidebarOpen(true)}
            className="p-2"
            data-testid="button-open-sidebar"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
            </svg>
          </Button>
        </div>

        {/* Content */}
        <div className={activeTab === 'dashboard' ? 'block' : 'hidden'}>
          {canAccessSection(userRole, 'inicio') && renderDashboard()}
        </div>
        <div className={activeTab === 'activities' ? 'block' : 'hidden'}>
          {canAccessSection(userRole, 'actividades') && renderActivitiesCalendar()}
        </div>
        <div className={activeTab === 'meal-calendar' ? 'block' : 'hidden'}>
          {canAccessSection(userRole, 'calendario_comidas') && renderMealCalendar()}
        </div>
        <div className={activeTab === 'inventory' ? 'block' : 'hidden'}>
          {canAccessSection(userRole, 'inventario') && renderInventory()}
        </div>
        <div className={activeTab === 'recipes' ? 'block' : 'hidden'}>
          {canAccessSection(userRole, 'recetas') && renderRecipes()}
        </div>
        <div className={activeTab === 'shopping-list' ? 'block' : 'hidden'}>
          {canAccessSection(userRole, 'lista_compra') && renderShoppingList()}
        </div>
        <div className={activeTab === 'messages' ? 'block' : 'hidden'}>
          {canAccessSection(userRole, 'mensajes') && renderMessages()}
        </div>
      </main>

      {/* Modals */}
      {showActivityModal && (
        <ActivityModal onClose={() => setShowActivityModal(false)} />
      )}
      {showMealModal && (
        <MealModal onClose={() => setShowMealModal(false)} />
      )}
      {showInventoryModal && (
        <InventoryModal onClose={() => setShowInventoryModal(false)} />
      )}
      {editingInventoryItem && (
        getUserPermissions(userRole, 'inventario').canAddItems ? (
          <InventoryEditModal 
            item={editingInventoryItem} 
            onClose={() => setEditingInventoryItem(null)}
            userRole={userRole}
            canAddItems={getUserPermissions(userRole, 'inventario').canAddItems}
          />
        ) : (
          <InventoryQuantityModal
            item={editingInventoryItem}
            onClose={() => setEditingInventoryItem(null)}
          />
        )
      )}
      <RecipeModal
        isOpen={showRecipeModal}
        onClose={() => setShowRecipeModal(false)}
      />
      {editingRecipe && (
        <RecipeEditModal
          recipe={editingRecipe}
          isOpen={true}
          onClose={() => setEditingRecipe(null)}
        />
      )}
    </div>
  );
}