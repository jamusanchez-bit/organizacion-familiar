import { Button } from "@/components/ui/button";
import { Calendar } from "lucide-react";
import sunriseImage from "@assets/generated_images/Sunrise_over_horizon_drawing_5741a59c.png";

export default function Landing() {
  const handleLogin = () => {
    window.location.href = "/api/login";
  };

  return (
    <div className="min-h-screen bg-neutral-50 flex items-center justify-center p-4">
      <div className="max-w-4xl w-full">
        <div className="text-center mb-12">
          <div className="flex items-center justify-center mb-6">
            <Calendar className="h-12 w-12 text-primary mr-3" />
            <h1 className="text-4xl font-bold text-neutral-800">Organización Familiar</h1>
          </div>
          <p className="text-xl text-neutral-600 mb-8 italic max-w-2xl mx-auto">
            "Si vives con gratitud, estás reprogramando tu cerebro para la abundancia." 
            <span className="block text-lg text-neutral-500 mt-2">— Joe Dispenza</span>
          </p>
          <Button 
            onClick={handleLogin}
            size="lg"
            className="bg-primary hover:bg-primary/90 text-white px-8 py-3"
            data-testid="button-login"
          >
            Iniciar Sesión
          </Button>
        </div>

        <div className="flex justify-center">
          <div className="max-w-2xl w-full">
            <img 
              src={sunriseImage} 
              alt="Sol saliendo por el horizonte" 
              className="w-full h-auto rounded-lg shadow-lg"
            />
          </div>
        </div>
      </div>
    </div>
  );
}
