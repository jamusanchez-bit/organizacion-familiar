import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { useQuery } from '@tanstack/react-query';
import SimpleLogin from '@/components/simple-login';

interface User {
  id: string;
  email: string;
  firstName: string;
}

interface AuthContextType {
  user: User | null;
  isLoading: boolean;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

interface AuthProviderProps {
  children: ReactNode;
}

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [shouldRetry, setShouldRetry] = useState(0);
  
  // Always use Replit auth in Replit environment (for now)
  const isIndependentMode = false;
  
  const { data: user, isLoading, error, refetch } = useQuery<User>({
    queryKey: [isIndependentMode ? '/api/simple-auth/user' : '/api/auth/user'],
    retry: false,
    staleTime: 5 * 60 * 1000, // 5 minutes
  });

  const logout = async () => {
    try {
      if (isIndependentMode) {
        await fetch('/api/simple-auth/logout', { method: 'POST' });
      } else {
        await fetch('/api/auth/logout', { method: 'POST' });
      }
      setShouldRetry(prev => prev + 1);
      refetch();
    } catch (error) {
      console.error('Logout error:', error);
      // Force re-fetch even if logout failed
      setShouldRetry(prev => prev + 1);
      refetch();
    }
  };

  const handleLoginSuccess = () => {
    setShouldRetry(prev => prev + 1);
    refetch();
  };

  // Show login screen if no user and not loading (in independent mode)
  if (!isLoading && !user && isIndependentMode) {
    return <SimpleLogin onLoginSuccess={handleLoginSuccess} />;
  }
  
  // For Replit mode, if no user, show regular landing page
  if (!isLoading && !user && !isIndependentMode) {
    // Let the normal Replit auth flow handle this
  }

  return (
    <AuthContext.Provider value={{ user: user || null, isLoading, logout }}>
      {children}
    </AuthContext.Provider>
  );
};