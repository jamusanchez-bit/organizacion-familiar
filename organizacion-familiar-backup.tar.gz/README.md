# 🏠 Organización Familiar

Una aplicación web completa para la gestión personal y familiar, con calendario de actividades, planificación de comidas, control de inventario y sistema de mensajes.

## ✨ Características Principales

- **👥 Sistema Multi-Usuario**: 5 perfiles familiares con permisos diferenciados
- **📅 Calendario de Actividades**: Gestión personal de actividades con duración y repetición
- **🍽️ Planificación de Comidas**: Calendario semanal con 8 tipos de comidas específicas
- **📦 Control de Inventario**: Gestión de stock con categorías y alertas de stock bajo
- **🛒 Lista de la Compra**: Organizada por categorías con auto-adición de productos sin stock
- **📝 Sistema de Recetas**: Gestión completa de recetas con ingredientes
- **💬 Mensajes**: Foro familiar, sugerencias al administrador y mensajes privados
- **🌅 Inicio Diario**: Fecha actual y frases motivacionales

## 🔐 Sistema de Usuarios

### Administrador
- **javi_administrador**: Acceso completo a todas las funciones
  - Crear, editar y eliminar en todos los módulos
  - Gestión completa de inventario y recetas
  - Acceso a todos los mensajes

### Usuarios Familiares
- **Javier, Raquel, Mario, Alba**: Permisos limitados
  - Solo ven sus propias actividades
  - Solo visualización en calendario de comidas
  - Solo pueden ajustar cantidades en inventario
  - Acceso limitado a mensajes

## 🛠️ Stack Tecnológico

### Frontend
- **React 18** con TypeScript
- **Vite** para desarrollo y construcción
- **Tailwind CSS** para estilos
- **shadcn/ui** para componentes
- **TanStack Query** para gestión de estado
- **Wouter** para routing

### Backend
- **Node.js** con Express
- **PostgreSQL** con Drizzle ORM
- **Autenticación dual** (Replit Auth + simple auth)
- **Sesiones** almacenadas en PostgreSQL

## 🚀 Desarrollo Local

### Requisitos
- Node.js 18+
- PostgreSQL
- npm o yarn

### Configuración
```bash
# Clonar repositorio
git clone <tu-repositorio>
cd organización-familiar

# Instalar dependencias
npm install

# Configurar variables de entorno
cp .env.example .env
# Editar .env con tu configuración de base de datos

# Ejecutar migraciones
npm run db:migrate

# Iniciar en modo desarrollo
npm run dev
```

### Variables de Entorno
```
DATABASE_URL=postgresql://usuario:password@localhost:5432/organización_familiar
SESSION_SECRET=tu_clave_secreta_muy_larga
NODE_ENV=development
```

## 📱 Deployment

### Opciones Recomendadas

#### Railway (Todo en uno)
1. Conecta tu repositorio GitHub
2. Configura variables de entorno
3. Deploy automático

#### Render + Neon
1. Base de datos en Neon (10GB gratis)
2. Aplicación en Render (750 horas gratis)

#### Netlify + Supabase
1. Frontend en Netlify
2. Backend en Railway
3. Base de datos en Supabase

Ver [DEPLOYMENT.md](./DEPLOYMENT.md) para instrucciones detalladas.

## 📁 Estructura del Proyecto

```
├── client/                 # Frontend React
│   ├── src/
│   │   ├── components/     # Componentes UI
│   │   ├── pages/         # Páginas principales
│   │   ├── hooks/         # Hooks personalizados
│   │   ├── lib/           # Utilidades
│   │   └── utils/         # Funciones auxiliares
├── server/                # Backend Express
│   ├── routes.ts          # Rutas API
│   ├── db.ts             # Configuración base de datos
│   └── authRoutes.ts     # Rutas de autenticación
├── shared/                # Tipos y esquemas compartidos
│   └── schema.ts         # Esquemas Drizzle
└── migrations/           # Migraciones de base de datos
```

## 🎨 Interfaz de Usuario

- **Responsive**: Funciona en móvil, tablet y escritorio
- **Tema claro**: Diseño limpio y profesional
- **Navegación intuitiva**: Sidebar con iconos claros
- **Feedback visual**: Notificaciones y estados de carga

## 🔄 Funciones Clave

### Calendario de Actividades
- Duración configurable (5-1440 minutos)
- Repetición (diario, semanal, días específicos)
- Vista diaria y semanal
- Asignación por usuario

### Gestión de Comidas
- 8 tipos de comidas por usuario
- Integración con recetas
- Descuento automático de ingredientes
- Navegación semanal

### Control de Inventario
- Categorías personalizadas
- Alertas de stock bajo
- Ubicación de compra
- Actualización rápida de cantidades

### Lista de la Compra
- Organizada por categorías:
  - Carne internet
  - Pescadería
  - Del bancal a casa
  - Alcampo
  - Internet
  - Otros
- Auto-adición de productos sin stock
- Sugerencias por categoría

## 📊 Base de Datos

### Tablas Principales
- `users`: Información de usuarios
- `activities`: Actividades del calendario
- `meals`: Tipos de comidas
- `meal_plans`: Planificación semanal
- `inventory_items`: Productos del inventario
- `recipes`: Recetas y sus ingredientes
- `shopping_list`: Lista de la compra
- `messages`: Sistema de mensajes
- `sessions`: Sesiones de usuario

## 🔒 Autenticación

El sistema incluye **autenticación dual**:

- **Desarrollo/Replit**: Usa Replit Auth con OIDC
- **Producción independiente**: Sistema simple email/password

Los usuarios están predefinidos y se crean automáticamente.

## 🤝 Contribución

1. Fork el proyecto
2. Crea una rama para tu feature
3. Commit tus cambios
4. Push a la rama
5. Abre un Pull Request

## 📄 Licencia

Este proyecto es de uso personal/familiar.

---

**¡Disfruta organizando tu familia! 🎉**