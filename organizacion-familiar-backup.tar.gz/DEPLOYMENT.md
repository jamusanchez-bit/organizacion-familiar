# Guía Completa: Migración a Visual Studio Code

## 📱 Desarrollo en iPad con Visual Studio Code Web

### Opción 1: GitHub Codespaces (Recomendado para iPad)
1. **Crear cuenta en GitHub** (si no tienes una)
   - Ve a [github.com](https://github.com) y regístrate gratis

2. **Subir tu proyecto a GitHub**
   - Desde Replit, descarga todos los archivos como ZIP
   - Crea un nuevo repositorio en GitHub
   - Sube todos los archivos del proyecto

3. **Usar GitHub Codespaces**
   - Desde tu repositorio en GitHub, click en "Code" > "Codespaces" > "Create codespace"
   - Se abrirá Visual Studio Code en tu navegador
   - **Plan gratuito**: 120 horas al mes (suficiente para desarrollo personal)

### Opción 2: Visual Studio Code para Web (vscode.dev)
1. Ve a [vscode.dev](https://vscode.dev) desde tu iPad
2. Conecta con tu cuenta de GitHub
3. Abre tu repositorio directamente

## 💻 Desarrollo en Mac con Visual Studio Code

### 1. Instalar herramientas necesarias
```bash
# Instalar Homebrew (gestor de paquetes para Mac)
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"

# Instalar Node.js
brew install node

# Instalar Visual Studio Code
brew install --cask visual-studio-code

# Instalar Git
brew install git
```

### 2. Clonar y configurar el proyecto
```bash
# Clonar tu repositorio
git clone https://github.com/tu-usuario/organización-familiar.git
cd organización-familiar

# Instalar dependencias
npm install

# Configurar variables de entorno
cp .env.example .env
# Editar .env con tus configuraciones
```

## 🗄️ Base de Datos: Opciones Gratuitas

### Opción 1: Neon (Recomendado)
- **Ventajas**: 10GB gratis, compatible con PostgreSQL, fácil configuración
- **Registro**: [neon.tech](https://neon.tech)
- **Configuración**:
  1. Crear cuenta gratuita
  2. Crear nueva base de datos
  3. Copiar la URL de conexión
  4. Añadirla a tu archivo `.env`

### Opción 2: Supabase
- **Ventajas**: 500MB gratis, interfaz visual, APIs automáticas
- **Registro**: [supabase.com](https://supabase.com)

### Opción 3: Railway
- **Ventajas**: PostgreSQL + hosting en un solo lugar
- **Registro**: [railway.app](https://railway.app)

## 🚀 Hosting de la Aplicación

### Opción 1: Railway (Todo en uno - Recomendado)
1. **Registro**: [railway.app](https://railway.app)
2. **Conectar GitHub**: Autoriza Railway a acceder a tu repositorio
3. **Deploy automático**: Railway detecta automáticamente tu proyecto Node.js
4. **Variables de entorno**: Configura en el panel de Railway
5. **Dominio**: Railway proporciona un dominio gratuito

### Opción 2: Render + Neon
1. **Base de datos**: Neon (como se explicó arriba)
2. **Hosting**: [render.com](https://render.com)
   - 750 horas gratuitas al mes
   - SSL automático
   - Deploy desde GitHub

### Opción 3: Netlify + Supabase (Solo si separas frontend/backend)
- Frontend en Netlify
- Backend en Railway o Render
- Base de datos en Supabase

## ⚙️ Configuración del Sistema de Autenticación

Tu proyecto ya está preparado con **autenticación dual**:

### En desarrollo local (Mac):
```javascript
// El sistema detecta automáticamente el entorno
// y usa autenticación simple (email/password)
```

### En producción (Railway/Render):
```javascript
// Configura estas variables en tu servicio de hosting:
NODE_ENV=production
SESSION_SECRET=tu_clave_secreta_muy_larga_y_aleatoria
DATABASE_URL=tu_url_de_postgresql
```

## 📋 Paso a Paso: Migración Completa

### Para iPad (Inicio inmediato):
1. ✅ Crea cuenta en GitHub
2. ✅ Sube tu proyecto como repositorio
3. ✅ Crea un Codespace gratuito
4. ✅ Configura base de datos en Neon
5. ✅ Deploy en Railway conectando tu GitHub

### Para Mac (Setup completo):
1. ✅ Instala herramientas (Homebrew, Node.js, VS Code)
2. ✅ Clona el repositorio
3. ✅ Configura entorno local
4. ✅ Conecta con base de datos
5. ✅ Desarrollo local completo

## 🔧 Variables de Entorno Necesarias

Crea un archivo `.env` con:
```
# Base de datos
DATABASE_URL=postgresql://usuario:password@host:puerto/database

# Autenticación
SESSION_SECRET=clave_secreta_muy_larga_y_aleatoria_de_al_menos_32_caracteres

# Entorno
NODE_ENV=production
```

## 🎯 Comandos Útiles

```bash
# Desarrollo local
npm run dev

# Construcción para producción
npm run build

# Migraciones de base de datos
npm run db:migrate

# Generar tipos de base de datos
npm run db:generate
```

## 💡 Consejos Importantes

1. **GitHub Codespaces es perfecto para iPad**: 120 horas gratuitas al mes
2. **Railway es la opción más simple**: Base de datos + hosting en un lugar
3. **Tu proyecto ya está preparado**: El sistema de autenticación dual funciona automáticamente
4. **Backups**: GitHub guarda automáticamente tu código
5. **Colaboración**: Puedes trabajar desde iPad y Mac con el mismo repositorio

## 🆘 Solución de Problemas

### Error de conexión a base de datos:
- Verifica que la URL en `.env` sea correcta
- Asegúrate de que la base de datos acepta conexiones externas

### Error de autenticación:
- El sistema usa autenticación simple en desarrollo
- Usuarios predeterminados ya configurados

### Error de deployment:
- Verifica que todas las variables de entorno estén configuradas
- Asegúrate de que `NODE_ENV=production`

---

## 📞 ¿Necesitas ayuda?

Si tienes problemas durante la migración, documenta:
1. Qué paso estás intentando
2. Qué error aparece exactamente
3. Qué navegador/dispositivo usas

**¡Tu aplicación está lista para funcionar independientemente!** 🎉