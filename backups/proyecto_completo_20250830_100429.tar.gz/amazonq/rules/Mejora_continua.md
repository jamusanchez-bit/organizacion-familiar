Si durante el desarrollo identificas una regla, patrón o práctica que podría mejorar el proyecto, sugiérela proactivamente.

Ejemplos: optimizaciones, mejores prácticas, prevención de errores, automatizaciones útiles.