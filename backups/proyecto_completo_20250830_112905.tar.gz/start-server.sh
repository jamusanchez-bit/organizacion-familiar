#!/bin/bash
cd "/Users/mgt/app familiar/organizacion-familiar"
node server-simple.cjs &
echo "Servidor arrancado en segundo plano"
echo "Visita http://localhost:8000"